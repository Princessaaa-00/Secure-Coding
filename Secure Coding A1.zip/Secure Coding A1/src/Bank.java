public class Bank {

    // Fields of the class Bank are created here
    private String accountType;
    private double accountBalance;
// This is a method deposit that adds to the accountBalance and returns the value
    public double deposit(double amount) {
        accountBalance += amount;
        return accountBalance;
    }
// This is to ensure that if the amount to be withdrawn is more than the accountBalance, it won't be withdrawn.
    public double withdrawal(double amount) {
        if (amount > accountBalance) {
            System.out.println("Insufficient funds");
            return accountBalance;
        }
        // This is a method withdrawal that subtracts from the accountBalance and returns the value.
        accountBalance -= amount;
        return accountBalance;
    }

    public Bank(String accountType, double accountBalance) {
        this.accountType = accountType;
        this.accountBalance = accountBalance;
    }

    public void display() {
        System.out.println("The account type is " + accountType + " and the balance is " + accountBalance);
    }


}



