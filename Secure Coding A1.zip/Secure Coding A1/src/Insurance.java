
// The extends keyword inherits from Bank Class
public class Insurance extends Bank {
    public Insurance(String accountType, double accountBalance) {
        super(accountType, accountBalance);
    }

    public void cover() {
        System.out.println("You are covered");
    }
}
